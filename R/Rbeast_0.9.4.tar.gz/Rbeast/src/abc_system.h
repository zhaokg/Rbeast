#pragma once

extern volatile int ctrl_C_Pressed;
extern void RegisterCtrlCHandler();
