#include "abc_datatype.h"
extern void QuickSortD(F32PTR arr,I32PTR INDEX,I32 low,I32 high);
extern void QuickSortA(rF32PTR arr,I32PTR INDEX,I32 low,I32 high);
